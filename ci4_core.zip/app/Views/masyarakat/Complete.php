<?= $this->extend('Layout/Base'); ?>

<?= $this->section('content'); ?>

<body> 
    
    <div class="container mt-5 text-center ">
        <div class="text-center">
            <div class="card" style="width: 64.1rem; margin-left: 100px;">
                <div style="
                width: 1024px;
                height: 52.301px;
                flex-shrink: 0;
                border-radius: 5px 5px 0px 0px;
                background: #E83B3B;
                  "></div>
            <div class="card-body">
              <h1 class="card-title fw-bold">Terimakasih atas laporan anda!</h1>
              <h5 class="card-text">Kami akan segera memproses laporan anda, mohon tunggu dengan sabar ya!</h5>
             
            </div>
          </div>
        </div>
        
    </div>




</body>

</html>


<?= $this->endSection(); ?>